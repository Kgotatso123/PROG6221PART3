﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

namespace RecipeManager
{
    public partial class MainWindow : Window
    {
        private List<Recipe> recipes = new List<Recipe>();
        private List<Ingredient> currentIngredients = new List<Ingredient>();

        public MainWindow()
        {
            InitializeComponent();
            AddPlaceholderTextToAll();
        }

        private void AddPlaceholderTextToAll()
        {
            AddPlaceholderText(RecipeNameTextBox, null);
            AddPlaceholderText(IngredientNameTextBox, null);
            AddPlaceholderText(CaloriesTextBox, null);
            AddPlaceholderText(FoodGroupTextBox, null);
            AddPlaceholderText(IngredientFilterTextBox, null);
            AddPlaceholderText(FoodGroupFilterTextBox, null);
            AddPlaceholderText(MaxCaloriesFilterTextBox, null);
        }

        private void AddPlaceholderText(object sender, RoutedEventArgs e)
        {
            if (sender is TextBox textBox && string.IsNullOrEmpty(textBox.Text))
            {
                textBox.Text = textBox.Tag.ToString();
                textBox.Foreground = Brushes.Gray;
            }
        }

        private void RemovePlaceholderText(object sender, RoutedEventArgs e)
        {
            if (sender is TextBox textBox && textBox.Text == textBox.Tag.ToString())
            {
                textBox.Text = string.Empty;
                textBox.Foreground = Brushes.Black;
            }
        }

        private void AddIngredient_Click(object sender, RoutedEventArgs e)
        {
            string ingredientName = IngredientNameTextBox.Text.Trim();
            if (int.TryParse(CaloriesTextBox.Text.Trim(), out int calories) && !string.IsNullOrEmpty(ingredientName) && ingredientName != IngredientNameTextBox.Tag.ToString())
            {
                string foodGroup = FoodGroupTextBox.Text.Trim();
                if (foodGroup == FoodGroupTextBox.Tag.ToString())
                {
                    foodGroup = string.Empty;
                }

                Ingredient newIngredient = new Ingredient
                {
                    Name = ingredientName,
                    Calories = calories,
                    FoodGroup = foodGroup
                };
                currentIngredients.Add(newIngredient);
                UpdateIngredientsList();
                ClearIngredientFields();
            }
            else
            {
                MessageBox.Show("Please enter valid ingredient details.");
            }
        }

        private void AddRecipe_Click(object sender, RoutedEventArgs e)
        {
            string recipeName = RecipeNameTextBox.Text.Trim();
            if (!string.IsNullOrEmpty(recipeName) && recipeName != RecipeNameTextBox.Tag.ToString() && currentIngredients.Any())
            {
                Recipe newRecipe = new Recipe
                {
                    Name = recipeName,
                    Ingredients = new List<Ingredient>(currentIngredients)
                };
                recipes.Add(newRecipe);
                UpdateRecipeList();
                ClearRecipeFields();
                currentIngredients.Clear();
                UpdateIngredientsList();
            }
            else
            {
                MessageBox.Show("Please enter a valid recipe name and add at least one ingredient.");
            }
        }

        private void UpdateRecipeList()
        {
            RecipesListBox.ItemsSource = null;
            RecipesListBox.ItemsSource = recipes.OrderBy(r => r.Name);
        }

        private void UpdateIngredientsList()
        {
            IngredientsListBox.ItemsSource = null;
            IngredientsListBox.ItemsSource = currentIngredients;
            TotalCaloriesTextBlock.Text = $"Total Calories: {currentIngredients.Sum(i => i.Calories)}";
        }

        private void ClearIngredientFields()
        {
            IngredientNameTextBox.Text = IngredientNameTextBox.Tag.ToString();
            CaloriesTextBox.Text = CaloriesTextBox.Tag.ToString();
            FoodGroupTextBox.Text = FoodGroupTextBox.Tag.ToString();
            IngredientNameTextBox.Foreground = Brushes.Gray;
            CaloriesTextBox.Foreground = Brushes.Gray;
            FoodGroupTextBox.Foreground = Brushes.Gray;
        }

        private void ClearRecipeFields()
        {
            RecipeNameTextBox.Text = RecipeNameTextBox.Tag.ToString();
            RecipeNameTextBox.Foreground = Brushes.Gray;
        }

        private void RecipesListBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (RecipesListBox.SelectedItem is Recipe selectedRecipe)
            {
                IngredientsListBox.ItemsSource = selectedRecipe.Ingredients;
                TotalCaloriesTextBlock.Text = $"Total Calories: {selectedRecipe.Ingredients.Sum(i => i.Calories)}";
            }
        }

        private void ApplyFilter_Click(object sender, RoutedEventArgs e)
        {
            string ingredientFilter = IngredientFilterTextBox.Text.Trim();
            string foodGroupFilter = FoodGroupFilterTextBox.Text.Trim();
            if (!int.TryParse(MaxCaloriesFilterTextBox.Text.Trim(), out int maxCalories))
            {
                maxCalories = int.MaxValue;
            }

            var filteredRecipes = recipes.Where(r =>
                (string.IsNullOrEmpty(ingredientFilter) || r.Ingredients.Any(i => i.Name.Contains(ingredientFilter))) &&
                (string.IsNullOrEmpty(foodGroupFilter) || r.Ingredients.Any(i => i.FoodGroup.Contains(foodGroupFilter))) &&
                r.Ingredients.Sum(i => i.Calories) <= maxCalories).ToList();

            RecipesListBox.ItemsSource = filteredRecipes.OrderBy(r => r.Name);
        }
    }

    public class Recipe
    {
        public string Name { get; set; }
        public List<Ingredient> Ingredients { get; set; }
    }

    public class Ingredient
    {
        public string Name { get; set; }
        public int Calories { get; set; }
        public string FoodGroup { get; set; }
    }
}
